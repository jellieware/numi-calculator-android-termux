# MinMax extension for Numi

## What is this extension for? :mag_right:

This extension allows you to determine the minimum or the maximum number in a set of numbers.

## Installation :floppy_disk:

Simply download the .js file to your numi extensions directory.

## How to use it :wrench:

```
nmin(5;3;7) // 3

x = 7
y = 25
nmax(x;y) // 25
```
